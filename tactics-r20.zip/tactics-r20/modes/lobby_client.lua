--[[**************************************************************************
*
*  ПРОЕКТ:        TACTICS MODES
*  ВЕРСИЯ ДВИЖКА: 1.2-r18
*  РАЗРАБОТЧИКИ:  Александр Романов <lexr128@gmail.com>
*
****************************************************************************]]
function Lobby_onClientMapStopping(mapinfo)
	if (mapinfo.modename ~= "lobby") then return end
	removeCommandHandler("car",toggleVehicleManager)
	removeCommandHandler("gun",toggleWeaponManager)
end
function Lobby_onClientMapStarting(mapinfo)
	if (mapinfo.modename ~= "lobby") then return end
	setPlayerHudComponentVisible("ammo",true)
	setPlayerHudComponentVisible("area_name",false)
	setPlayerHudComponentVisible("armour",true)
	setPlayerHudComponentVisible("breath",true)
	setPlayerHudComponentVisible("clock",true)
	setPlayerHudComponentVisible("health",true)
	setPlayerHudComponentVisible("money",false)
	setPlayerHudComponentVisible("radar",true)
	setPlayerHudComponentVisible("vehicle_name",false)
	setPlayerHudComponentVisible("weapon",true)
	if (getRoundModeSettings("car") == "true") then
		addCommandHandler("car",toggleVehicleManager,false)
	end
	if (getRoundModeSettings("gun") == "true") then
		addCommandHandler("gun",toggleWeaponManager,false)
	end
end
addEventHandler("onClientMapStarting",root,Lobby_onClientMapStarting)
addEventHandler("onClientMapStopping",root,Lobby_onClientMapStopping)
