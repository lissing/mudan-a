--Gamemode Script Name
gameName = "SPAR - TACTICS TREINING"
function gamemodeName ()
		setGameType (gameName)
end

addEventHandler ( "onResourceStart", getRootElement(), gamemodeName )

